//
//  Result.swift
//  HairStylePreview
//
//  Created by 곽재선 on 2021/05/07.
//

import UIKit

class Result: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
}
