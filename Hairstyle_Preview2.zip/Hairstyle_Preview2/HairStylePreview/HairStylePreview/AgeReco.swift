//
//  AgeReco.swift
//  HairStylePreview
//
//  Created by 김정태 on 2021/04/05.
//

import UIKit

class Tabbar1: UIViewController{
    
    @IBOutlet var Appname: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
