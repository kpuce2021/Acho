//
//  FaceReco.swift
//  HairStylePreview
//
//  Created by 김정태 on 2021/04/05.
//

import UIKit

class Recommend: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
