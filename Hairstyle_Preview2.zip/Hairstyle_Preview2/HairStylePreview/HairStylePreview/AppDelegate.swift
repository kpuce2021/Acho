//
//  AppDelegate.swift
//  HairStylePreview
//
//  Created by 김정태 on 2021/04/05.
//

import UIKit
import Amplify
import AmplifyPlugins
import AWSCognitoIdentityProvider
import AWSS3


@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func initializeS3() {
        let poolId = "ap-northeast-2_vRzCiWpb9" // 3-1
                let credentialsProvider = AWSCognitoCredentialsProvider(regionType: .APNortheast2, identityPoolId: poolId)//3-2
                let configuration = AWSServiceConfiguration(region: .APNortheast2, credentialsProvider: credentialsProvider)
                AWSServiceManager.default().defaultServiceConfiguration = configuration
        }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        self.initializeS3()
        do {
                try Amplify.add(plugin: AWSCognitoAuthPlugin())
                try Amplify.add(plugin: AWSS3StoragePlugin())
                try Amplify.configure()
                print("Amplify configured with storage plugin")
            } catch {
                print("An error occurred setting up Amplify: \(error)")
            }
        
        Thread.sleep(forTimeInterval: 1.5)
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }

}

