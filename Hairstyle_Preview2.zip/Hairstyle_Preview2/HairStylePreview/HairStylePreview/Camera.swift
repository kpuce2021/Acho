//
//  Camera.swift
//  HairStylePreview
//
//  Created by 곽재선 on 2021/05/06.
//

import Foundation
import UIKit
import MobileCoreServices
import Amplify
import Combine
import AWSS3


class Camera: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var imgView: UIImageView!
    
    
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var s3UrlLabel: UILabel!
    
    
    let imagePicker: UIImagePickerController! = UIImagePickerController()
    var captureImage: UIImage!
    var flagImageSave = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.progressView.progress = Float(0.0)
    }
    
    
    
    
    // In your type's instance variables
    var resultSink: AnyCancellable?
    var progressSink: AnyCancellable?

    // ...
    
    func uploadData() {
    
        let dataString = "My Data"
        let fileNameKey = "myFile.txt"
        let filename = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileNameKey)
        do {
            try dataString.write(to: filename, atomically: true, encoding: String.Encoding.utf8)
        } catch {
            print("Failed to write to file \(error)")
        }

        let storageOperation = Amplify.Storage.uploadFile(key: fileNameKey, local: filename)
        let progressSink = storageOperation.progressPublisher.sink { progress in print("Progress: \(progress)") }
        let resultSink = storageOperation.resultPublisher.sink {
            if case let .failure(storageError) = $0 {
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        receiveValue: { data in
            print("Completed: \(data)")
        }
    }
    
    
    
    
    @IBAction func btnSelectImage(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)  
        
        let popupVC = storyBoard.instantiateViewController(identifier: "PopupHair")
        
        popupVC.modalPresentationStyle = .overCurrentContext
        self.present(popupVC, animated: false, completion: nil)
        
        /*
        guard let image = UIImage(named: "1") else {return}
        if let data = image.pngData(){
            DispatchQueue.main.async(execute: {
                let transferUtility = AWSS3TransferUtility.default()
                let S3BucketName = "hairstylepreview86674eed24ee40bfb4734283e0afc6c183114-dev"
                let expression = AWSS3TransferUtilityUploadExpression()

                transferUtility.uploadData(data, bucket: S3BucketName, key: "1", contentType: "image/png", expression: expression) { (task, error) in
                    if let error = error{
                        print(error.localizedDescription)
                        return
                    }
                    print("uploaded successfully")
                }
            })

        }
        */
        
        guard let image = UIImage(named: "1") else { return } //1
            AWSS3Manager.shared.uploadImage(image: image, progress: {[weak self] ( uploadProgress) in
                
                guard let strongSelf = self else { return }
                strongSelf.progressView.progress = Float(uploadProgress)//2
                
            }) {[weak self] (uploadedFileUrl, error) in
                
                guard let strongSelf = self else { return }
                if let finalPath = uploadedFileUrl as? String { // 3
                    strongSelf.s3UrlLabel.text = "Uploaded file url: " + finalPath
                } else {
                    print("\(String(describing: error?.localizedDescription))","111") // 4
                }
            }
        
        
    
        
        //guard let image = UIImage(named: "3") else { return } //1
        //    AWSS3Manager.shared.uploadImage(image: image, progress: {[weak self] ( uploadProgress) in
        //        print("진행중..")
        //    }) {[weak self] (uploadedFileUrl, error) in
        //        print("진행중..")
        //    }
        
        //uploadData()
        
    }
    
    @IBAction func btnCaptureImage(_ sender: UIButton) {
        if(UIImagePickerController.isSourceTypeAvailable(.camera)) {
            flagImageSave = true
            
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            imagePicker.mediaTypes = [kUTTypeImage as String]
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        } else {
            myAlert("camera inaccessable", message: "Application cannot access the camera.")
        }
    }
    
    @IBAction func btnLoadImage(_ sender: UIButton) {
        if(UIImagePickerController.isSourceTypeAvailable(.photoLibrary)) {
            flagImageSave = false
            
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.mediaTypes = [kUTTypeImage as String]
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        } else {
            myAlert("photo album inaccessable", message: "Application cannot access the photo album.")
        }
    }
    
    func myAlert(_ title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        captureImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        
        if flagImageSave {
            UIImageWriteToSavedPhotosAlbum(captureImage, self, nil, nil)
        }
        
        imgView.image = captureImage
        
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}
