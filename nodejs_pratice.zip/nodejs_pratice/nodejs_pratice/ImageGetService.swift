//
//  ImageGetService.swift
//  nodejs_pratice
//
//  Created by 김정태 on 2021/05/29.
//

import Foundation
import UIKit
import Alamofire

struct ImageGetService: APIService {
    
    static func getImgae(image: UIImage, completion: @escaping (_ result: String) -> Void) {
        var imageURL = "http://localhost:8888/tree/Acho/data/src"
        Alamofire.request(.GET,).response() {
          (_, _, data, _) in
          let image = UIImage(data: data! as! NSData)
        }
    }
}

//Alamofire.request(.GET, "http://localhost:8888/tree/Acho/data/src/yes/*" ).response { //(request, response, data , error) in
    //print("success2")
    //}
/*
Alamofire.request( "https://robohash.org/123.png%22",method: .get).response{response in
    switch response.result {
    case .success(let responseData):
        self.myImageView.image = UIImage(data: responseData!, scale:1)

    case .failure(let error):
        print("error--->",error)
    }
}
 Alamofire.request(.GET, "https://robohash.org/123.png%22").response { (request, response, data, error) in
         self.myImageView.image = UIImage(data: data, scale:1)
     }
*/
