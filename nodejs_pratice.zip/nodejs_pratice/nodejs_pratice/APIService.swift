protocol APIService {
    
}

extension APIService {
    
    /* 네트워킹 통신을 할 때, 보통 하나의 서버 URL을 가지고 경로만 바뀌게 됩니다.
    네트워킹 통신 메소드마다 하나하나 주소를 넣는 번거로움을 덜기 위해 또는 주소가 바뀌었을 때, 한번에 변경할 수 있도록
    아래의 메소드를 정의하여 조금더 편리하게 통신할 수 있도록 합니다.
     */
    static func url(_ path: String) -> String {
        return "http://ec2-52-78-189-15.ap-northeast-2.compute.amazonaws.com:3000" + path
    }
    
    static func url2(_ path: String) -> String {
        return "http://localhost:8888/tree/Acho/data/src" + path
    }
}

