//
//  ViewController.swift
//  nodejs_pratice
//
//  Created by 김정태 on 2021/05/21.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    let imagePicker : UIImagePickerController = UIImagePickerController()
    var imagePickerFlag : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //imageView.image = UIImage(named:"123.jpg")
    }


    @IBAction func uploadImage(_ sender: Any) {
        postImage()
    }
    
}

extension ViewController {
    
    //MARK: 이미지 업로드 - POST
    //Rekognition 서버에 이미지를 업로드하여 가장 높은 표정 값을 반환받습니다.
    
    /* completion에 보낸 result 값을 result라는 변수로 받아 사용합니다.
     변수명은 이름은 원하시는대로 지으셔도 상관없습니다.
     */
    func postImage() {
        imageView.image = UIImage(named:"0006.png")
        ImageUploadService.postImage(image: imageView.image!) {(result) in
            print("success upload image")
        }
    }
}
